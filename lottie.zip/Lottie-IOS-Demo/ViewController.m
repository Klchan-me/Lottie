//
//  ViewController.m
//  Lottie-IOS-Demo
//
//  Created by erickchen on 2017/4/10.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import "ViewController.h"
#import <Lottie/Lottie.h>

@interface ViewController ()
@property (nonatomic, strong) LOTAnimationView *lottieLogo;
@property (nonatomic, strong) UIButton *lottieButton;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.lottieLogo = [LOTAnimationView animationNamed:@"data"];
//    self.lottieLogo.backgroundColor = [UIColor clearColor];
//    self.lottieLogo.contentMode = UIViewContentModeScaleAspectFill;
    [self.view addSubview:self.lottieLogo];
    
    self.lottieButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.lottieButton addTarget:self action:@selector(_playLottieAnimation) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.lottieButton];
    self.view.backgroundColor = [UIColor blackColor];

}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.lottieLogo play];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [self.lottieLogo pause];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGRect lottieRect = CGRectMake((self.view.frame.size.width-405/2)/2, (self.view.frame.size.height-442/2)/2, 405/2, 442/2);
    self.lottieLogo.frame = lottieRect;
    self.lottieButton.frame = lottieRect;
}

- (void)_playLottieAnimation {
    self.lottieLogo.animationProgress = 0;
    [self.lottieLogo play];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
